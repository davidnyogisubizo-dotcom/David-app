# David App — Android project

This project wraps the current David App HTML into an Android WebView application.

## Build
Open the project in Android Studio, let Gradle sync, then build:
- APK: Build > Build APK(s)
- Play Store package: Build > Generate Signed Bundle / APK > Android App Bundle

The current app data is local to the device. Wallet actions are simulation only, and authentication is local prototype logic; a production release should add a secure backend and real payment integration.

Release preparation: versionCode 2, versionName 1.1.
